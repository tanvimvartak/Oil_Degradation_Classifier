"""
Flask web application for Oil Degradation Classifier.
Provides a user-friendly interface for uploading images and getting predictions.
"""

from flask import Flask, render_template, request, jsonify
import torch
from PIL import Image
import io
import base64
import sys
from pathlib import Path

# Add src to path
sys.path.insert(0, str(Path(__file__).parent / 'src'))

from config import Config
from preprocessing import ImagePreprocessor
from model import OilDegradationCNN
import numpy as np

app = Flask(__name__)

# Global variables for model and preprocessor
model = None
preprocessor = None
device = None
config = None

def load_model():
    """Load the trained model."""
    global model, preprocessor, device, config
    
    config = Config()
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    
    # Initialize preprocessor
    preprocessor = ImagePreprocessor(image_size=config.IMAGE_SIZE)
    
    # Load model
    model = OilDegradationCNN(num_classes=config.NUM_CLASSES)
    
    # Load trained weights
    checkpoint = torch.load(config.MODEL_SAVE_PATH, map_location=device, weights_only=False)
    model.load_state_dict(checkpoint['model_state_dict'])
    model = model.to(device)
    model.eval()
    
    print(f"Model loaded successfully on {device}")

def predict_image(image):
    """
    Predict oil degradation stage from image.
    
    Args:
        image: PIL Image
    
    Returns:
        dict: Prediction results
    """
    # Preprocess image
    transform = preprocessor.get_val_transforms()
    image_tensor = transform(image).unsqueeze(0).to(device)
    
    # Make prediction
    with torch.no_grad():
        outputs = model(image_tensor)
        probabilities = torch.softmax(outputs, dim=1)
        confidence, predicted_class = torch.max(probabilities, 1)
    
    # Get class name
    class_names = config.CLASS_NAMES
    predicted_label = class_names[predicted_class.item()]
    
    # Get all class probabilities
    all_probs = probabilities[0].cpu().numpy()
    
    # Map to usage description
    usage_map = {
        "fresh.oil": "Fresh Oil (Never Used)",
        "1.time.use.oil": "Used Once",
        "2.time.use.oil": "Used Twice",
        "3.time.use.oil": "Used Three Times"
    }
    
    # Recommendation based on usage
    recommendations = {
        "fresh.oil": "✓ Safe to use. Oil is fresh and suitable for cooking.",
        "1.time.use.oil": "✓ Safe to use. Oil can be reused once more.",
        "2.time.use.oil": "⚠ Caution. Consider replacing soon. Oil quality is degrading.",
        "3.time.use.oil": "✗ Not recommended. Replace oil immediately for health safety."
    }
    
    return {
        'predicted_class': predicted_label,
        'usage_description': usage_map[predicted_label],
        'confidence': float(confidence.item() * 100),
        'recommendation': recommendations[predicted_label],
        'all_probabilities': {
            'Fresh Oil': float(all_probs[0] * 100),
            'Used Once': float(all_probs[1] * 100),
            'Used Twice': float(all_probs[2] * 100),
            'Used Three Times': float(all_probs[3] * 100)
        }
    }

@app.route('/')
def index():
    """Render the main page."""
    return render_template('index.html')

@app.route('/predict', methods=['POST'])
def predict():
    """Handle image upload and prediction."""
    try:
        if 'file' not in request.files:
            return jsonify({'error': 'No file uploaded'}), 400
        
        file = request.files['file']
        
        if file.filename == '':
            return jsonify({'error': 'No file selected'}), 400
        
        # Read and process image
        image_bytes = file.read()
        image = Image.open(io.BytesIO(image_bytes)).convert('RGB')
        
        # Make prediction
        result = predict_image(image)
        
        # Convert image to base64 for display
        buffered = io.BytesIO()
        image.save(buffered, format="JPEG")
        img_str = base64.b64encode(buffered.getvalue()).decode()
        result['image'] = f"data:image/jpeg;base64,{img_str}"
        
        return jsonify(result)
    
    except Exception as e:
        return jsonify({'error': str(e)}), 500

@app.route('/health')
def health():
    """Health check endpoint."""
    return jsonify({'status': 'healthy', 'model_loaded': model is not None})

if __name__ == '__main__':
    print("Loading model...")
    load_model()
    print("Starting Flask server...")
    app.run(debug=True, host='0.0.0.0', port=8000)
